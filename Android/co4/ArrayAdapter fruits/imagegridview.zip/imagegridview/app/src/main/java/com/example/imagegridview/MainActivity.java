package com.example.imagegridview;

// Import statements
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

// MainActivity class
public class MainActivity extends AppCompatActivity {

    // Arrays storing fruit names and corresponding image resources
    String[] fruitNames = {"Apple", "Mango", "Cherry", "Lemon"};
    int[] fruitImages = {R.drawable.apple, R.drawable.mango, R.drawable.cherry, R.drawable.lemon};

    // onCreate method
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Find GridView by ID
        GridView gridView = findViewById(R.id.grid);

        // Create and set the adapter for the GridView
        ImageAdapter imageAdapter = new ImageAdapter(this, fruitNames, fruitImages);
        gridView.setAdapter(imageAdapter);

        // Set item click listener for the GridView
        gridView.setOnItemClickListener((parent, view, position, id) ->
                Toast.makeText(MainActivity.this, "You've clicked " + fruitNames[position], Toast.LENGTH_SHORT).show());
    }

    // ImageAdapter class
    private static class ImageAdapter extends BaseAdapter
    {
        private Context mContext;
        private String[] mFruitNames;
        private int[] mFruitImages;

        // Constructor
        public ImageAdapter(Context context, String[] fruitNames, int[] fruitImages)
        {
            mContext = context;
            mFruitNames = fruitNames;
            mFruitImages = fruitImages;
        }

        @Override
        public int getCount()
        {
            return mFruitImages.length;
        }

        @Override
        public Object getItem(int position)
        {
            return mFruitImages[position];
        }

        @Override
        public long getItemId(int position)
        {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ImageView imageView;
            if (convertView == null)
            {

                imageView = new ImageView(mContext);
                imageView.setLayoutParams(new GridView.LayoutParams(350, 350)); // Adjust size as needed
            }
            else
            {

                imageView = (ImageView) convertView;
            }

            imageView.setImageResource(mFruitImages[position]);
            return imageView;
        }
    }
}
