package com.example.arradapter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    ListView mylistview;
    String courselist[]={
            "java",
            "python",
            "c++"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mylistview=(ListView) findViewById(R.id.l1);
        ArrayAdapter<String> arrayAdapter =new ArrayAdapter<String>(this,R.layout.list,R.id.t1,courselist);
        mylistview.setAdapter(arrayAdapter);
        mylistview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String item=(String)mylistview.getItemAtPosition(i);
                Toast.makeText(MainActivity.this, "Your selected course is "+item, Toast.LENGTH_SHORT).show();


            }
        });

    }
}