package com.example.crud;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button b1,b2,b3,b4;
    EditText rollno,name,address;
    DbHelper helper=new DbHelper(this);
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db=helper.getReadableDatabase();
        db=helper.getWritableDatabase();
        b1=findViewById(R.id.b1);
        b2=findViewById(R.id.b2);
        b3=findViewById(R.id.b3);
        b4=findViewById(R.id.b4);
        rollno=findViewById(R.id.e1);
        name=findViewById(R.id.e2);
        address=findViewById(R.id.e3);
    }


    public void insert(View view)
    {
       String s1=rollno.getText().toString();
       String s2=name.getText().toString();
       String s3=address.getText().toString();
       ContentValues data=new ContentValues();
       data.put("rollno",s1);
       data.put("name",s2);
       data.put("address",s3);
       db.insert("student_tb",null,data);
       Toast.makeText(this, "inserted", Toast.LENGTH_SHORT).show();

    }



    public void update(View view)
    {

        String s1=rollno.getText().toString();
        String s2=name.getText().toString();
        String s3=address.getText().toString();
        ContentValues data=new ContentValues();
        data.put("rollno",s1);
        data.put("name",s2);
        data.put("address",s3);
        db.update("student_tb",data,"rollno="+s1,null);
        Toast.makeText(this, "updated", Toast.LENGTH_SHORT).show();

    }

    public void read(View view)
    {

        StringBuffer bf=new StringBuffer();
        Cursor c=db.rawQuery("select * from student_tb",null);
        while(c.moveToNext())
        {
            bf.append("Roll no: "+c.getString(0)+"\t");
            bf.append("name is: "+c.getString(1));
            bf.append("Address is: "+c.getString(2));

        }
        Toast.makeText(this,bf.toString(),Toast.LENGTH_LONG).show();
    }

    public void delete(View view)
    {
        String s1=rollno.getText().toString();
        
        db.delete("student_tb","rollno="+s1,null);
        Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show();
    }
}