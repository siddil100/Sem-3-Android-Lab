package com.example.empcrud;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button b1,b2,b3,b4;
    EditText name,dept,phone,upid;
    DbHelper helper=new DbHelper(this);
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db=helper.getReadableDatabase();
        db=helper.getWritableDatabase();
        b1=findViewById(R.id.b1);
        b2=findViewById(R.id.b2);
        b3=findViewById(R.id.b3);
        b4=findViewById(R.id.b4);
        name=findViewById(R.id.e1);
        dept=findViewById(R.id.e2);
        phone=findViewById(R.id.e3);
        upid=findViewById(R.id.e10);
    }

    public void insert(View view)
    {
        String s1=name.getText().toString();
        String s2=dept.getText().toString();
        String s3=phone.getText().toString();
        ContentValues data=new ContentValues();
        data.put("name",s1);
        data.put("dept",s2);
        data.put("phone",s3);
        db.insert("emp_tb",null,data);
        Toast.makeText(this, "inserted", Toast.LENGTH_SHORT).show();


    }


    public void update(View view)
    {
        String s1=name.getText().toString();
        String s2=dept.getText().toString();
        String s3=phone.getText().toString();
        String s4=upid.getText().toString();
        ContentValues data=new ContentValues();
        data.put("name",s1);
        data.put("dept",s2);
        data.put("phone",s3);
        db.update("emp_tb",data,"empid="+s4,null);
        Toast.makeText(this, "updated", Toast.LENGTH_SHORT).show();


    }

    public void read(View view)
    {
        StringBuffer bf=new StringBuffer();
        Cursor c=db.rawQuery("select * from emp_tb",null);
        while(c.moveToNext())
        {
            bf.append("Empid is : "+c.getString(0)+"\t");
            bf.append("name is: "+c.getString(1)+"\t");
            bf.append("dept is: "+c.getString(2)+"\t");
            bf.append("phone is is: "+c.getString(3)+"\t");

        }
        Toast.makeText(this,bf.toString(),Toast.LENGTH_LONG).show();


    }

    public void delete(View view)
    {
        String s4=upid.getText().toString();

        db.delete("emp_tb","empid="+s4,null);
        Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show();

    }
}